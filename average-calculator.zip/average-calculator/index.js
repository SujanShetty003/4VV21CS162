const express = require('express');
const axios = require('axios');

const app = express();
const PORT = 9876;
const WINDOW_SIZE = 10;

const THIRD_PARTY_API = {
  p: 'http://20.244.56.144/test/primes',
  f: 'http://20.244.56.144/test/fibo',
  e: 'http://20.244.56.144/test/even',
  r: 'http://20.244.56.144/test/rand'
};

let window = [];
let API_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiZXhwIjoxNzIwMjQzNDUwLCJpYXQiOjE3MjAyNDMxNTAsImlzcyI6IkFmZm9yZG1lZCIsImp0aSI6IjYwM2MzMjRjLWIxOGUtNDJiYy1iOWI2LWY4Mzc3NWZlNjdmMyIsInN1YiI6InN1amFuc2hldHR5MDAzQGdtYWlsLmNvbSJ9LCJjb21wYW55TmFtZSI6ImdvTWFydCIsImNsaWVudElEIjoiNjAzYzMyNGMtYjE4ZS00MmJjLWI5YjYtZjgzNzc1ZmU2N2YzIiwiY2xpZW50U2VjcmV0IjoiVUFacm5lRklQQ3pBZW5BUyIsIm93bmVyTmFtZSI6InN1amFuIFIiLCJvd25lckVtYWlsIjoic3VqYW5zaGV0dHkwMDNAZ21haWwuY29tIiwicm9sbE5vIjoiNFZWMjFDUzE2MiJ9.H1pqCw0_GhRc2RecW5s1uBHuJqpJpNtjTyZMqNCUtUQ";

// Register company function
const registerCompany = async () => {
  try {
    const response = await axios.post('http://20.244.56.144/test/register', {
      companyName: 'goMart',
      ownerName: 'sujan R',
      rollNo: '4VV21CS162',
      ownerEmail: 'sujanshetty003@gmail.com',
      accessCode: 'pwiPKW'
    });
    return response.data;
  } catch (error) {
    if (error.response && error.response.status === 409) {
      console.log('Company already registered, skipping registration.');
      return {
        clientID: '603c324c-b18e-42bc-b9b6-f83775fe67f3',
        clientSecret: 'UAZrneFIPCzAenAS'
      };
    }
    console.error('Error registering company:', error.message);
    throw error;
  }
};

// Authenticate function
const authenticate = async (clientID, clientSecret) => {
  try {
    const response = await axios.post('http://20.244.56.144/test/auth', {
      companyName: 'goMart',
      clientID,
      clientSecret,
      ownerName: 'sujan R',
      ownerEmail: 'sujanshetty003@gmail.com',
      rollNo: '4VV21CS162'
    });
    return response.data.access_token;
  } catch (error) {
    console.error('Error authenticating:', error.message);
    throw error; 
  }
};


const fetchNumbers = async (numberid) => {
  try {
    const response = await axios.get(THIRD_PARTY_API[numberid], {
      headers: {
        Authorization: `Bearer ${API_TOKEN}`
      },
      timeout: 500
    });
    console.log(`Fetched numbers for ${numberid}:`, response.data.numbers);
    return response.data.numbers || [];
  } catch (error) {
    console.error(`Error fetching numbers for ${numberid}:`, error.message);
    throw error; 
  }
};


const updateWindow = (newNumbers) => {
  const windowPrevState = [...window];

  newNumbers.forEach(number => {
    if (!window.includes(number)) {
      if (window.length >= WINDOW_SIZE) {
        window.shift(); 
      }
      window.push(number);
    }
  });

  console.log('Updated window:', window);

  return { windowPrevState, windowCurrState: [...window] };
};

const calculateAverage = (numbers) => {
  if (numbers.length > 0) {
    const sum = numbers.reduce((acc, num) => acc + num, 0);
    return sum / numbers.length;
  }
  return 0;
};


app.get('/', (req, res) => {
  res.send('Average Calculator Microservice. Use the endpoint /numbers/:numberid where numberid can be p, f, e, or r.');
});


app.get('/numbers/:numberid', async (req, res) => {
  const { numberid } = req.params;

  if (!THIRD_PARTY_API[numberid]) {
    return res.status(400).json({ error: 'Invalid number ID' });
  }

  try {
    const newNumbers = await fetchNumbers(numberid);
    const { windowPrevState, windowCurrState } = updateWindow(newNumbers);
    const avg = calculateAverage(windowCurrState);

    const response = {
      windowPrevState,
      windowCurrState,
      numbers: newNumbers,
      avg: parseFloat(avg.toFixed(2))
    };

    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch numbers or update window.' });
  }
});

const startServer = async () => {
  try {
    const registrationData = await registerCompany();
    if (registrationData) {
      const { clientID, clientSecret } = registrationData;
      API_TOKEN = await authenticate(clientID, clientSecret);
      if (API_TOKEN) {
        app.listen(PORT, () => {
          console.log(`Server is running on http://localhost:${PORT}`);
        });
      } else {
        console.error('Failed to obtain API token.');
      }
    } else {
      console.error('Failed to register company.');
    }
  } catch (error) {
    console.error('Error starting server:', error.message);
  }
};


startServer();
